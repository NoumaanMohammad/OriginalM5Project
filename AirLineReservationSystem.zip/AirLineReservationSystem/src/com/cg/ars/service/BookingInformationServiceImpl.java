package com.cg.ars.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ars.dao.BookingInformationDao;
import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;


@Service
@Transactional
public class BookingInformationServiceImpl implements BookingInformationService {
	
	@Autowired
	BookingInformationDao dao;

	@Override
	public BookingInformation getBookingDetailsById(int bookId)
			throws AirLineManagementException {
		return dao.getBookingDetailsById(bookId);
	}

	@Override
	public int deleteBookingById(int bookId) throws AirLineManagementException {
		return dao.deleteBookingById(bookId);
	}

	@Override
	public int bookTicket(BookingInformation booking)
			throws AirLineManagementException {
		return dao.bookTicket(booking);
	}

	@Override
	public int sequenceForSeats() throws AirLineManagementException {
		return dao.sequenceForSeats();
	}

	@Override
	public BookingInformation updateTicketDetails(BookingInformation oldBooking,BookingInformation newBooking)
			throws AirLineManagementException {													//Idhi bombaiiii
		return dao.updateTicketDetails(oldBooking,newBooking);
	}

	@Override
	public boolean seatManagementForUpdateTicket(BookingInformation oldBooking,
			BookingInformation newBooking, FlightInformation flight)
			throws AirLineManagementException {
		boolean status=true;
		
				if((oldBooking.getClassType().toLowerCase()).contains("fir")) {    
					int seats=oldBooking.getPassengers()+flight.getFirstSeats();
			
					
						if((newBooking.getClassType().toLowerCase()).contains("fir")) {
							if(newBooking.getPassengers()>seats) {
								status=false;
							} else if(newBooking.getPassengers()>flight.getBussSeats()) { 
								status=false;
							}
						}
					
				} else if((oldBooking.getClassType().toLowerCase()).contains("bus")) {
						int totalSeats=oldBooking.getPassengers()+flight.getBussSeats();
						
							if((newBooking.getClassType().toLowerCase()).contains("fir")) {
								if(newBooking.getPassengers()>flight.getFirstSeats()) {
									status=false;
								} else if(newBooking.getPassengers()>totalSeats) {
									status=false;
								}
							}
					
				}
				
		return status;
	}

	

}
