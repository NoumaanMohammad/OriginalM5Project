package com.cg.ars.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;

public interface FlightInformationService 
{

	public void addFlight(FlightInformation fi) throws AirLineManagementException;
	public FlightInformation getFlightById(int FlightNum) throws AirLineManagementException;
	public FlightInformation updateFlightFaresById(FlightInformation fares) throws AirLineManagementException;
	public FlightInformation updateFlightCitiesById(FlightInformation cities) throws AirLineManagementException;
	public FlightInformation updateFlightScheduleById(FlightInformation flight) throws  AirLineManagementException;

	public List<FlightInformation> getFlightDetailsByCities(String srcCity,String destCity) throws AirLineManagementException;


}
