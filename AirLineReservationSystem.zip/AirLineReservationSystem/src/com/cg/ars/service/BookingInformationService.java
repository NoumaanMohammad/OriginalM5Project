package com.cg.ars.service;

import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;

public interface BookingInformationService {

	public BookingInformation getBookingDetailsById(int bookId) throws AirLineManagementException;
	public int deleteBookingById(int bookId) throws AirLineManagementException;
	public int bookTicket(BookingInformation booking) throws AirLineManagementException;
	public int sequenceForSeats() throws AirLineManagementException;
	public BookingInformation updateTicketDetails(BookingInformation oldBooking,BookingInformation newBooking) throws AirLineManagementException;
	public boolean seatManagementForUpdateTicket(BookingInformation oldBooking,BookingInformation newBooking,FlightInformation flight) throws AirLineManagementException;
	
	


}
