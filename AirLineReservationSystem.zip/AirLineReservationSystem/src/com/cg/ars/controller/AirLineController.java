package com.cg.ars.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.dto.Users;
import com.cg.ars.exception.AirLineManagementException;
import com.cg.ars.service.BookingInformationService;
import com.cg.ars.service.FlightInformationService;
import com.cg.ars.service.UsersService;
import com.cg.ars.util.StringToDate;

@Controller
public class AirLineController {
	
	@Autowired
	BookingInformationService bookingService;
	@Autowired
	FlightInformationService flightser;
	
	@Autowired
	UsersService userService;
	
	
	
	@InitBinder
	public void  initBinder(WebDataBinder binder)
	{
		binder.registerCustomEditor(Date.class, new StringToDate());
	}
	
	@RequestMapping(value="/home")      //homepage(common for all)
	public String goToHome() {
		return "homePage";
	}
	
	
	
	
	
	
//**********************************************************************************************
	//user(Noumaan)
	
	@RequestMapping(value="/user")
	public String userModule(Model m) {
		return "userPage";
	}
	
	@RequestMapping(value="/bookTicket")
	public String bookTicketPage(Model m) {
		m.addAttribute("ticket", new BookingInformation());
		
		return "bookTicketForm";
	}
	
	
	@RequestMapping(value="/processGetFlightDetailsByCities")
	public String processGetFlightDetailsByCities(@RequestParam("srcCity") String srcCity,@RequestParam("destCity") String destCity,Model m){
		List<FlightInformation> list;
		try {
		list=flightser.getFlightDetailsByCities(srcCity, destCity);
			if(list.size()==0) {
				m.addAttribute("msg", "There are no flights with given cities");
				return "bookTicketForm"; 		
			} else
		m.addAttribute("flight",list);
		} catch(AirLineManagementException e) {
			m.addAttribute("msg",e.getMessage());
		}
		
		
		return "bookTicketForm"; 											//****************************
	}
	
	@RequestMapping(value="/bookTicketPage")
	public String bookTicketPageforUser(@RequestParam("flightNo") int flightNo,Model m){
		
		m.addAttribute("flightNo", flightNo);
		FlightInformation flight=flightser.getFlightById(flightNo);
		
		m.addAttribute("fSeatMsg", "available firsCLass Seats"+flight.getFirstSeats());
		m.addAttribute("bSeatMsg", "available BusinessCLass Seats"+flight.getBussSeats());

		m.addAttribute("booking", new BookingInformation());
		
		return "bookTicketPage";
	}
	
	@RequestMapping(value="/processBookTicket",method=RequestMethod.GET)
	public String processBookTicket(@RequestParam("flightNo") int flightNo,@Valid @ModelAttribute("booking") BookingInformation booking,BindingResult result,Model m){
		int rows=0;
		try {
				
			if(result.hasErrors()) {
				m.addAttribute("booking",booking);
				
				return "bookTicketPage";
			} 
			FlightInformation flight=flightser.getFlightById(flightNo);
			
				if((booking.getClassType()).toLowerCase().contains("first")) {
					if(booking.getPassengers()>flight.getFirstSeats()) {
						m.addAttribute("seatAvailableMsg", "There are no available seats for "+booking.getPassengers()+" passengers");
						return "bookTicketPage";
					}
				} else if((booking.getClassType()).toLowerCase().contains("bus")) {
					if(booking.getPassengers()>flight.getBussSeats()) {
						m.addAttribute("seatAvailableMsg", "There are no available seats for "+booking.getPassengers()+" passengers");
						return "bookTicketPage";
					}
				}
				
			booking.setFlightno(flight.getFlightNo());
			double totalFare=0;
			if((booking.getClassType().toLowerCase()).contains("first")) {
				totalFare=flight.getFirstSeatsFare()*booking.getPassengers();
			} else if((booking.getClassType().toLowerCase()).contains("bus")) {
				totalFare=flight.getBussSeatsFare()*booking.getPassengers();

			}
			booking.setTotalFare(totalFare);
			booking.setSourceCity(flight.getDeptCity());
			booking.setDestCity(flight.getArrCity());
			int seatNumber=0;
			for(int i=0;i<booking.getPassengers();i++) {
					if(i==0) {
						seatNumber=bookingService.sequenceForSeats();
						continue;
						
					}
					bookingService.sequenceForSeats();
				
			}
			
			
			booking.setSeatNumber("seatNo Starts with "+seatNumber);
			rows=bookingService.bookTicket(booking);
				if(rows==0) {
					m.addAttribute("msg", "Sorry not able to book a ticket");
				}
				else 
					m.addAttribute("msg", "your Ticket No is "+rows);
			
			
			
		} catch(AirLineManagementException e) {
			m.addAttribute("msg", e.getMessage());

		}
		
		return "bookTicketPage";
	}
	
	
	
	@RequestMapping(value="/viewBookDetailsForUserById")
	public String viewBookDetailsusingId(Model m) {
		
			return "viewBookDetailsForUserByIdPage";
	}
	
	@RequestMapping(value="/processviewBookDetailsForUserById")
	public String processviewBookDetailsusingId(@RequestParam("bookId") int bookId,Model m) {
		try {
			BookingInformation bookInfo=bookingService.getBookingDetailsById(bookId);
			
			if(bookInfo==null) {
				m.addAttribute("emptymsg","There are no Bookings with the given Id");
			}
			else
			m.addAttribute("bookInfo",bookInfo);
		} catch (AirLineManagementException e) {
			m.addAttribute("errmsg",e.getMessage());
		}
		return "viewBookDetailsForUserByIdPage";
	}
	
	@RequestMapping(value="/cancelTicketForUserById")
	public String cancelTicketForUserById(@RequestParam("bookId") int bookId,Model m){
		int rows=0;
		
			try {
		rows=bookingService.deleteBookingById(bookId);
			if(rows!=0) {
				m.addAttribute("dltemsg","Ticket Cancellation Successful");
				return "viewBookDetailsForUserByIdPage";
			} else 
				m.addAttribute("dltemsg", "not cancelled");
			} catch(AirLineManagementException e) {
				m.addAttribute("dltemsg",e.getMessage());
			}
		return "viewBookDetailsForUserByIdPage";
	}
	
	
	
	@RequestMapping(value="/updateBookDetailsById")
	public String updateBookDetailsById(@RequestParam("bookId") int bookId,Model m) {
		
		BookingInformation booking=bookingService.getBookingDetailsById(bookId);
		FlightInformation flight=flightser.getFlightById(booking.getFlightno());
	
		m.addAttribute("fSeatMsg", "available firsCLass Seats"+flight.getFirstSeats());
		m.addAttribute("bSeatMsg", "available BusinessCLass Seats"+flight.getBussSeats());

		m.addAttribute("bookId",bookId);
		m.addAttribute("bookInfo", new BookingInformation());
		
		return "updateBookDetailsByIdForm";
		
	}
	
	@RequestMapping(value="/processUpdateTicket")
	public String processUpdateTicket(@RequestParam("bookId") int bookId,@Valid @ModelAttribute("booking") BookingInformation newBooking,BindingResult result,Model m){
			if(result.hasErrors()) {
				return "updateBookDetailsByIdForm";
			}
		try {	
			BookingInformation oldBooking=bookingService.getBookingDetailsById(bookId);
			
			
			FlightInformation flight=flightser.getFlightById(oldBooking.getFlightno());
			
			boolean seatManaged=bookingService.seatManagementForUpdateTicket(oldBooking, newBooking, flight);
			System.out.println(seatManaged);
				if(!seatManaged) {
					m.addAttribute("seatAvailableMsg", "There are no available seats for "+newBooking.getPassengers()+" passengers");
					return "updateBookDetailsByIdForm";

				}
			
			double totalFare=0;
				if((newBooking.getClassType().toLowerCase()).contains("fir")) {
					totalFare=newBooking.getPassengers()*flight.getFirstSeatsFare();
				} else if((newBooking.getClassType().toLowerCase()).contains("bus")) {
					totalFare=newBooking.getPassengers()*flight.getBussSeatsFare();
				}
			newBooking.setTotalFare(totalFare);
			newBooking.setBookingId(bookId);
			BookingInformation book=bookingService.updateTicketDetails(oldBooking,newBooking); //main
			m.addAttribute("bookInfo", book);
			
		} catch(Exception e) {
			m.addAttribute("msg", e.getMessage());
			return "updateBookDetailsByIdForm";
		}
		
		return "viewBookDetailsForUserByIdPage";
		
	}
	
	



//*************************************************************************************************

	@RequestMapping(value="admin")
	public String adminModule(Model model){
		model.addAttribute("user", new Users());
		return "adminLoginPage";
	}
	
	@RequestMapping(value="/validateLoginAdmin")
   public String validateAdminLogin(@Valid @ModelAttribute("user") Users admin,BindingResult result,Model model){
		
		if(result.hasErrors()) {
			return "adminLoginPage";
		}
		
		try {
		
			Users dto=userService.validateAdminCredentials(admin);
			
		if(dto==null) {
			model.addAttribute("errmsg","Invalid UserName or Password");
			return "adminLoginPage";
		}
		
		} catch(AirLineManagementException e) {
			model.addAttribute("errmsg", e.getMessage());
			return "adminLoginPage";
		}
		
		return "adminMenu";
		
	}
	
	@RequestMapping(value="updateAndManage")
	public String adminupdate(Model m){
		return "updateAndManageMenu";
		
	}
	
	@RequestMapping(value="/addFlightDetails")
	public String addFlight(Model m)
	{
		m.addAttribute("flight", new FlightInformation());
		return "addFlight";
	}

	

@RequestMapping(value="/processaddFlight")
public String processAdd(@Valid @ModelAttribute("flight") FlightInformation flightInfo,BindingResult result,Model m ) throws AirLineManagementException
{
	if(flightInfo.getFlightNo()<0||(!Pattern.matches("[0-9]{5}", flightInfo.getFlightNo()+""))) {
		m.addAttribute("flightNomsg", "flight number should not be negative and must be 5 digits=");
		return "addFlight";
	}
	else if(flightInfo.getArrCity().equalsIgnoreCase(flightInfo.getDeptCity())) {
		m.addAttribute("citiesMsg", "Arrival City and Departure city Shoul not be equal");
		return "addFlight";
	}
	else if(flightInfo.getBussSeatsFare()>flightInfo.getFirstSeatsFare()) {
		m.addAttribute("faremsg","First Class faer should be greater than business class fare");
		return "addFlight";
	}
	
	else if(flightInfo.getBussSeatsFare()<0||flightInfo.getFirstSeatsFare()<0) {
		m.addAttribute("negativeFareMsg","fare(s) should not negative");
		return "addFlight";
	}
	else if(flightInfo.getBussSeats()<0||flightInfo.getFirstSeats()<0) {
		m.addAttribute("seatsMsg","no of seats should not be negative");
	}
	else
	

	try {
		flightser.addFlight(flightInfo);
			m.addAttribute("msg","flightdetails added successfully");
			if(result.hasErrors()) {
				return "addFlight";
			}
			
			return "addFlight";
	}
	
	 catch (AirLineManagementException e) {
		m.addAttribute("excpmsg",e.getMessage());
		return "addFlight";
	}
	
	
	return "addFlight";
}
	
	@RequestMapping(value="/updateFlightFare")
	public String updateFaresOfFlight(Model m) {
		
		return "updateFlightFarePage";
	}
	
	@RequestMapping(value="/processUpdateFares")
	public String updateFlightFareProcess(@RequestParam("flightNo") int flightNo,Model model) {
		
		try {
			FlightInformation flight=flightser.getFlightById(flightNo);
			if(flight==null) {
				model.addAttribute("emptymsg","There are no records with given Flight number");
				return "updateFlightFarePage";
			}
			else
			{
				model.addAttribute("flight",flight);
			}
			} 
				catch(AirLineManagementException e) {
				model.addAttribute("errmsg",e.getMessage());
				return "updateFlightFarePage";
			}
			
		return "updateFlightFarePage";
		
	}
	
	@RequestMapping(value="/updateFlightFare2")
	public String updateFlightFare2(@RequestParam("flightNo") int flightNo,Model m){
		
		m.addAttribute("flightNo", flightNo);
		/*m.addAttribute("fares",new FlightInformation());*/
		return "updateFlightFare2Page";
	}
	
	@RequestMapping(value="processUpdateFlightFare2")
	public String processupdateFlightFare2(@RequestParam("flightNo") int flightNo,@RequestParam("firstFare") double firstFare
			,@RequestParam("bussFare") double bussFare,Model model)
	{
		
		FlightInformation flight;
		FlightInformation fares=new FlightInformation();
			if(firstFare<0||bussFare<0) {
				model.addAttribute("updatemsg","fare should not be negative");
				return updateFlightFareProcess(flightNo, model);
			}
			if(firstFare<bussFare) {
				model.addAttribute("updatemsg","businses class fare should be less than firstclass fare");
				return updateFlightFareProcess(flightNo, model);

			}
		try{
		fares.setFlightNo(flightNo);
		fares.setFirstSeatsFare(firstFare);
		fares.setBussSeatsFare(bussFare);
		
		
		flight=flightser.updateFlightFaresById(fares);
		model.addAttribute("flight", flight);
		} catch(AirLineManagementException e) {
			model.addAttribute("errmsg", e.getMessage());
			return "updateFlightFare2Page";
		}
		model.addAttribute("updatemsg", "Update Successfully");
		return updateFlightFareProcess(flightNo, model);
	}
	
	
	@RequestMapping(value="/updateCitiesOfFlight")
	public String updateCities(Model m) {
		
		return "updateCitiesPage";
	}
	
	
	@RequestMapping(value="/processUpdateCities")
	public String processUpdateFlightCities(@RequestParam("flightNo") int flightNo,Model model) {
		
		try {
			FlightInformation flight=flightser.getFlightById(flightNo);
			if(flight==null) {
				model.addAttribute("emptymsg","There are no records with given Flight number");
				return "updateCitiesPage";
			}
			else
			{
				model.addAttribute("flight",flight);
			}
			} 
				catch(AirLineManagementException e) {
				model.addAttribute("errmsg",e.getMessage());
				return "updateCitiesPage";
			}
			
		return "updateCitiesPage";
		
	}
	
	
	@RequestMapping(value="/updateCities2")
	public String updateCities2(@RequestParam("flightNo") int flightNo,Model m) {
		
		m.addAttribute("flightNo", flightNo);
		return "updateFlightcities2Page";
	}
	
	
	@RequestMapping(value="/processUpdateCitiesOfFlight")
	public String processUpdateCitiesOfFlight(@RequestParam("flightNo") int flightNo,@RequestParam("srcCity") String srcCity
			,@RequestParam("destCity") String destCity,Model model) {
		
		FlightInformation flight;
		FlightInformation cities=new FlightInformation();
		try{
		cities.setFlightNo(flightNo);
		cities.setDeptCity(srcCity);
		cities.setArrCity(destCity);
		flight=flightser.updateFlightCitiesById(cities);
		model.addAttribute("flight", flight);
		} catch(AirLineManagementException e) {
			model.addAttribute("errmsg", e.getMessage());
		}
		return "updateFlightcities2Page";
		
		
	}
	
	
	@RequestMapping(value="/updateFlightSchedule")
	public String updateFlightSchedule(Model m) {
		
		return "updateFlightSchedulePage";
	}
	
	
	
	@RequestMapping(value="/processUpdateSchedule")
	public String processUpdateSchedule(@RequestParam("flightNo") int flightNo,Model model) {
		try {
			FlightInformation flight=flightser.getFlightById(flightNo);
			if(flight==null) {
				model.addAttribute("emptymsg","There are no records with given Flight number");
				return "updateFlightSchedulePage";
			}
			else
			{
				model.addAttribute("flight",flight);
			}
			} 
				catch(AirLineManagementException e) {
				model.addAttribute("errmsg",e.getMessage());
				return "updateFlightSchedulePage";
			}
			
		return "updateFlightSchedulePage";
		
	}
	
	
	@RequestMapping(value="/updateSchedule2")
	public String updateSchedule2(@RequestParam("flightNo") int flightNo,Model m) {
		m.addAttribute("flightNo", flightNo);
		return "updateFlightSchedulePage2";
	}
	
	
	@RequestMapping(value="/processUpdateFlightSchedule2")
	public String processUpdateFlightSchedule2(@RequestParam("depDate") String depDate,@RequestParam("depTime") String depTime
			,@RequestParam("arrDate") String arrDate,@RequestParam("arrTime") String arrTime,@RequestParam("flightNo") int flightNo,Model model)
	{
		
		FlightInformation flight;
		FlightInformation flightInfo=new FlightInformation();
		try {
		    Date depDate1;
		    Date arrDate1;
			try {
				depDate1 = new SimpleDateFormat("dd-MM-yyyy").parse(depDate);
				arrDate1 = new  SimpleDateFormat("dd-MM-yyyy").parse(arrDate);
				flightInfo.setFlightNo(flightNo);
				flightInfo.setDeptDate(depDate1);
				flightInfo.setArrDate(arrDate1);
				flightInfo.setDeptTime(depTime);
				flightInfo.setArrTime(arrTime);
				flight=flightser.updateFlightScheduleById(flightInfo);
				model.addAttribute("flight", flight);

			} 
			catch (ParseException e) {
				e.printStackTrace();
			}  
		} catch(AirLineManagementException e) {
			model.addAttribute("errmsg",e.getMessage());
			return "updateFlightSchedulePage2";
		}
		
		
		model.addAttribute("updatemsg","Updated Successfully");
		return processUpdateSchedule(flightNo, model);
		
	}
	
	
	
	@RequestMapping(value="/viewFlightDetailsById")
	public String viewFlightDetailsById() {
		
		return "viewFlightDetailsByIdPage";
		
	}
	
	@RequestMapping(value="/processsGetFlightById")
	public String processsGetFlightById(@RequestParam("flightNo") int flightNo,Model model) {
		
		try {
		FlightInformation flight=flightser.getFlightById(flightNo);
		if(flight==null) {
			model.addAttribute("emptymsg","There are no records with given Flight number");
			return "viewFlightDetailsByIdPage";
		}
		else
		{
			model.addAttribute("flight",flight);
		}
		} 
			catch(AirLineManagementException e) {
			model.addAttribute("errmsg",e.getMessage());
			return "viewFlightDetailsByIdPage";
		}
		
		return "viewFlightDetailsByIdPage";
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="adminMenu")
	public String adminmenu(Model m)
	{
		System.out.println("admin menu");
		return "menuPg";
	}
	
	@RequestMapping(value="adminview")
	public String adminView(Model m)
	{
		return "adminViewMenu";
	}

@RequestMapping(value="schedule")
public String updateSchedule(Model m)
{
	return "schedule";
}
@RequestMapping(value="fare")
public String updateFare(Model m)
{
	return "fare";
}
@RequestMapping(value="srcanddest")	
public String updateSrcDest()
{
	return "srcanddest";
}

	
}














































