package com.cg.ars.util;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sun.org.apache.regexp.internal.recompile;

public class StringToDate extends PropertyEditorSupport{

	@Override
	public String getAsText() {
		
		Date value = null;
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		
		if(getValue()!=null)
		{
			value = (Date)getValue();
			
			
			return format.format(value);
		}
		else
			return "";
		
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		
		if(text.equals("")) 
			setValue("");
		
		Date value = null;
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		try {
			value = format.parse(text);
		} catch (ParseException e) {
			setValue(null);
			e.printStackTrace();
		}
		
		setValue(value);
	}
		
	
	
	
}
