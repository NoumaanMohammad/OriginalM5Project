package com.cg.ars.dao;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ars.dto.BookingInformation;
import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;



@Repository
public class BookingInformationDaoImpl implements BookingInformationDao {

	@PersistenceContext
	EntityManager entityManager;
	

	@Override
	public BookingInformation getBookingDetailsById(int bookId)
			throws AirLineManagementException {
		BookingInformation bookInfo;
		try {
			bookInfo=entityManager.find(BookingInformation.class, bookId);
			
		} catch(Exception e) {
			throw new AirLineManagementException("Not Able to view the data");
		}
		return bookInfo;
	}


	@Override
	public int deleteBookingById(int bookId) throws AirLineManagementException {
		
		BookingInformation booking;
		int update=0;
			try {
		booking=this.getBookingDetailsById(bookId);
		entityManager.remove(booking);
			if(this.getBookingDetailsById(bookId)==null) {
				if((booking.getClassType().toLowerCase()).contains("fir")) {
					
					javax.persistence.Query query = entityManager.createNativeQuery("update flightinformation set firstseats=firstseats+:seats where flightno=:flightNo",FlightInformation.class);
					query.setParameter("seats", booking.getPassengers());
					query.setParameter("flightNo", booking.getFlightno());
					update=query.executeUpdate();
					
				} else if((booking.getClassType().toLowerCase()).contains("bus")) {
					javax.persistence.Query query = entityManager.createNativeQuery("update flightinformation set bussseats=bussseats+:seats where flightno=:flightNo",FlightInformation.class);
					query.setParameter("seats", booking.getPassengers());
					query.setParameter("flightNo", booking.getFlightno());
					update=query.executeUpdate();
				}
			}
			} catch(Exception e) {
				throw new AirLineManagementException("not able to delete"+e.getMessage());
			}
			

		return update;
	}


	@Override
	public int bookTicket(BookingInformation booking)
			throws AirLineManagementException {
			int bookId=0,update=0;
			try {
				entityManager.persist(booking);
				entityManager.flush();
				bookId=booking.getBookingId();
					if(bookId!=0) {
						booking=this.getBookingDetailsById(bookId);
						
							if(booking!=null) {
								if((booking.getClassType().toLowerCase()).contains("fir")) {
									
									javax.persistence.Query query = entityManager.createNativeQuery("update flightinformation set firstseats=firstseats-:seats where flightno=:flightNo",FlightInformation.class);
									query.setParameter("seats", booking.getPassengers());
									query.setParameter("flightNo", booking.getFlightno());
									update=query.executeUpdate();
									
								} else if((booking.getClassType().toLowerCase()).contains("bus")) {
									javax.persistence.Query query = entityManager.createNativeQuery("update flightinformation set bussseats=bussseats-:seats where flightno=:flightNo",FlightInformation.class);
									query.setParameter("seats", booking.getPassengers());
									query.setParameter("flightNo", booking.getFlightno());
									update=query.executeUpdate();
								}
							}
						
					}
			} catch(Exception e) {
				throw new AirLineManagementException("not able to book ticket");
				
			}
		
		return bookId;
	}


	@Override
	public int sequenceForSeats() throws AirLineManagementException {
		BigDecimal seatNumber;
		javax.persistence.Query query;
		try {
			
			 query=entityManager.createNativeQuery("select seat_number_seq.nextval from dual");
			
			seatNumber= (BigDecimal)query.getSingleResult();
		} catch(Exception e) {
			e.printStackTrace();
			throw new AirLineManagementException("Not able to generate seat numbers");
		}
		return seatNumber.intValue();
	}


	@Override
	public BookingInformation updateTicketDetails(BookingInformation oldBooking,BookingInformation newBooking)
			throws AirLineManagementException {
		
		BookingInformation bookingInfo=null;
			try {
				
				if((oldBooking.getClassType().toLowerCase()).contains("fir")) {
					javax.persistence.Query query=entityManager.createNativeQuery("update FlightInformation set firstseats=firstseats+:fseats where flightNo=:flightNo",FlightInformation.class);
					query.setParameter("fseats",oldBooking.getPassengers());
					query.setParameter("flightNo",oldBooking.getFlightno());
						query.executeUpdate();
				} else if((oldBooking.getClassType().toLowerCase()).contains("bus")) {
					javax.persistence.Query query=entityManager.createNativeQuery("update FlightInformation set bussseats=bussseats+:bseats where flightNo=:flightNo",FlightInformation.class);
					query.setParameter("bseats",oldBooking.getPassengers());
					query.setParameter("flightNo",oldBooking.getFlightno());
						query.executeUpdate();
				}
				
				BookingInformation book=entityManager.find(BookingInformation.class, newBooking.getBookingId());
				System.out.println(" updating "+bookingInfo);
				
					if(book!=null) {
						book.setEmail(newBooking.getEmail());
						book.setPassengers(newBooking.getPassengers());
						book.setClassType(newBooking.getClassType());
						book.setTotalFare(newBooking.getTotalFare());
						book.setCreditCardInfo(newBooking.getCreditCardInfo());
						bookingInfo=entityManager.merge(book);
					}
					
					if((newBooking.getClassType().toLowerCase()).contains("fir")) {
						javax.persistence.Query query=entityManager.createNativeQuery("update FlightInformation set firstseats=firstseats-:fseats where flightNo=:flightNo",FlightInformation.class);
						query.setParameter("fseats",newBooking.getPassengers());
						query.setParameter("flightNo",newBooking.getFlightno());
							query.executeUpdate();
					} else if((newBooking.getClassType().toLowerCase()).contains("bus")) {
						javax.persistence.Query query=entityManager.createNativeQuery("update FlightInformation set bussseats=bussseats-:bseats where flightNo=:flightNo",FlightInformation.class);
						query.setParameter("bseats",newBooking.getPassengers());
						query.setParameter("flightNo",newBooking.getFlightno());
							query.executeUpdate();
					}
					
			} catch(Exception e) {
				throw new AirLineManagementException("updation failed");
			}
		
			System.out.println(" Returining "+bookingInfo);
		return bookingInfo;
	}

}
