package com.cg.ars.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ars.dto.FlightInformation;
import com.cg.ars.exception.AirLineManagementException;
@Repository
public class FlightInformationDaoImpl implements FlightInformationDao{
		@PersistenceContext
		EntityManager em;


	@Override
	public void addFlight(FlightInformation fi) throws AirLineManagementException {
		
		try {
			em.persist(fi);
			em.flush();

		} catch (Exception e) {

			throw new AirLineManagementException("not able to add flightdetails");
		}
		
	
	}
	@Override
	public FlightInformation getFlightById(int FlightNum)
			throws AirLineManagementException {
		FlightInformation flight;
		try {
			flight=em.find(FlightInformation.class, FlightNum);
		}
		 catch(Exception e) {
			 throw new AirLineManagementException("not able to retrieve data ");
		 }
		
		
		return flight;
	}
	@Override
	public FlightInformation updateFlightFaresById(FlightInformation fares)
			throws AirLineManagementException {
		FlightInformation flight1 = null;
		try{
			FlightInformation flight=em.find(FlightInformation.class, fares.getFlightNo());
			
			flight.setFirstSeatsFare(fares.getFirstSeatsFare());
			flight.setBussSeatsFare(fares.getBussSeatsFare());
			
			if(flight!=null) {
				flight=em.merge(flight);
				
				return flight;
			}
		} catch(Exception e) {
			e.printStackTrace();
			throw new AirLineManagementException("Not able to update");
		}
		return flight1;
	}
	
	@Override
	public FlightInformation updateFlightCitiesById(FlightInformation cities)
			throws AirLineManagementException {
		FlightInformation flight=null;
		try{
			FlightInformation flightInfo=em.find(FlightInformation.class, cities.getFlightNo());
			flightInfo.setDeptCity(cities.getDeptCity());
			flightInfo.setArrCity(cities.getArrCity());
			
			if(flightInfo!=null) {
				flight=em.merge(flightInfo);
				return flightInfo;
			}
		}catch(Exception e) {
			throw new AirLineManagementException("Not able to update");
		}

		return flight;
	}
	@Override
	public FlightInformation updateFlightScheduleById(FlightInformation flight)
			throws AirLineManagementException {
		FlightInformation flight2=null;

		try{
			FlightInformation flightInfo=em.find(FlightInformation.class, flight.getFlightNo());
			flightInfo.setDeptDate(flight.getDeptDate());
			flightInfo.setDeptTime(flight.getDeptTime());
			flightInfo.setArrDate(flight.getArrDate());
			flightInfo.setArrTime(flight.getArrTime());

				if(flightInfo!=null) {
					flight2=em.merge(flightInfo);
					return flight2;
				}

		} catch(Exception e){
			throw new AirLineManagementException("Not able to update");

		}
		return flight2;
	}
	@Override
	public List<FlightInformation> getFlightDetailsByCities(String srcCity,
			String destCity) throws AirLineManagementException {
			
		List<FlightInformation> list=new ArrayList<FlightInformation>();
		try {
			TypedQuery<FlightInformation> query=em.createQuery("from FlightInformation flight where flight.deptCity=:srcCity and flight.arrCity=:destCity", FlightInformation.class);
			query.setParameter("srcCity", srcCity);
			query.setParameter("destCity", destCity);
			list=query.getResultList();
			
		} catch(Exception e) {
			throw new AirLineManagementException("not able to retrieve data");
		}
		return list;
	}

}
