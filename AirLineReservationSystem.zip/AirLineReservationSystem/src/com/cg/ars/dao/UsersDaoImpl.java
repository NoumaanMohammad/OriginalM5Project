package com.cg.ars.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ars.dto.Users;
import com.cg.ars.exception.AirLineManagementException;

@Repository
public class UsersDaoImpl implements UsersDao {
	
	@PersistenceContext
	EntityManager entityManager;
	Users dto;

	@Override
	public Users validateAdminCredentials(Users admin)
			throws AirLineManagementException {
		try{
			TypedQuery<Users> query=entityManager.createQuery("from Users user where user.userName=:userName and user.password=:password", Users.class);
			query.setParameter("userName",admin.getUserName());
			query.setParameter("password", admin.getPassword());
			dto=query.getSingleResult();
		} catch(Exception e) {
			throw new AirLineManagementException("Invalid UserName or Password");
		}
		
		return dto;
	}

}
